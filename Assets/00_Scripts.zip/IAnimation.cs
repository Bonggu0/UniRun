using UnityEngine;
public interface IAnimation
{
    void Enter();
    void Update();
    EState Exit();
}
